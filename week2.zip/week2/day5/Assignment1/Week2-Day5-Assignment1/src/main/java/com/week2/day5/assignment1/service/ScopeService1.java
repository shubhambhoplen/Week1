package com.week2.day5.assignment1.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.week2.day5.assignment1.repo.ScopeRepo1;
import com.week2.day5.assignment1.repo.ScopeRepo2;

@Service
public class ScopeService1 {

	@Autowired
	private ScopeRepo1 repo1;
	
	@Autowired
	private ScopeRepo2 repo2;

	public ScopeRepo1 getRepo1() {
		return repo1;
	}
	
	public ScopeRepo2 getRepo2() {
		return repo2;
	}
}
