package com.week2.day5.assignment1.repo;

import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
public class ScopeRepo1 {
	
	static int value = 0;

	public ScopeRepo1() {
		System.out.println("ScopeRepo1() Constructor : "+ value++);
	}
	
}
