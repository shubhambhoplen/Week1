package com.week2.day5.assignment1.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.week2.day5.assignment1.service.ScopeService1;
import com.week2.day5.assignment1.service.ScopeService2;

@RestController
@RequestMapping("/scope")
public class ScopeController {
	
	@Autowired
	private ScopeService1 service1;
	
	@Autowired
	private ScopeService2 service2;
	
	@GetMapping("/ser1")
	public String getValue1() {
		boolean flag = service1.getRepo1().equals(service2.getRepo1());
		return flag ? "Same Object Created" : "Different Object created";
	}
	
	@GetMapping("/ser2")
	public String getValue2() {
		boolean flag = service1.getRepo2().equals(service2.getRepo2());
		return flag ? "Same Object Created" : "Different Object created";
	}

}
