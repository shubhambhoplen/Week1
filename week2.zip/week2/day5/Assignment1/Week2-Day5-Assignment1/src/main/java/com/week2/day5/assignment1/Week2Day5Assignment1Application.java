package com.week2.day5.assignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week2Day5Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day5Assignment1Application.class, args);
	}

}
