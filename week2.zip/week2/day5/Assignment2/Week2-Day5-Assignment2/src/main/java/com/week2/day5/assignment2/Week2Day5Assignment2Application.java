package com.week2.day5.assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*#2. Make necessary changes in given RestTemplate example, to perform delete operation?*/

@SpringBootApplication
public class Week2Day5Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day5Assignment2Application.class, args);
	}

}
