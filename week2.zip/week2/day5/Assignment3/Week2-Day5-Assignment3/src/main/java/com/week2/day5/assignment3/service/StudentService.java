package com.week2.day5.assignment3.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.week2.day5.assignment3.domain.Student;

@Service
public class StudentService {
	
private static List<Student> students;
	
	static{
		students = getStudentData();
	}
	
	@Cacheable("student")
	public Student getStudentByID(String id) {
		try {
			Thread.sleep(1000*5);
			System.out.println("First time loading");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return new Student(id,"Sajal" ,"V");
	}
	
	@Cacheable(value="students", key="#name", unless="#result==null")
	public Student getByName(String name) {
		System.out.println("<!----------Entering getByName()--------------------->");
		for(Student std : students){
			if(std.getName().equalsIgnoreCase(name))
				return std;
		}
		return null;
	}
	
	@CacheEvict(value = "students", allEntries = true)
	public void refreshAllStudents() {
		//This method will remove all 'Students' from cache, say as a result of flush API.
	}	
	
	@CachePut(value = "students", key = "#student.name" , unless="#result==null")
	public Student updateStudent(Student student) {
		System.out.println("<!----------Entering updateStudent ------------------->");
		for(Student std : students){
			if(std.getName().equalsIgnoreCase(student.getName()))
				std.setId(student.getId());
				std.setClz(student.getClz());
				return std;
		}
		return null;
	}
	

	private static List<Student> getStudentData(){
		List<Student> students = new ArrayList<Student>();
		students.add(new Student("101","Student_1","College_1"));
		students.add(new Student("102","Student_2","College_2"));
		students.add(new Student("103","Student_3","College_3"));
		return students;
	}
}
