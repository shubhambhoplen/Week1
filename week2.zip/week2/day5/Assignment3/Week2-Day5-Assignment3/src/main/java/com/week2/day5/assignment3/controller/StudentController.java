package com.week2.day5.assignment3.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.week2.day5.assignment3.domain.Student;
import com.week2.day5.assignment3.service.StudentService;

@RestController
public class StudentController {
	
	@Autowired
	private StudentService studentService;
	
	@GetMapping("/student/{name}")
	public Student findStudentById(@PathVariable String name) {
		Student std = studentService.getByName(name);
		System.out.println("Student :"+std);
		return std;
	}
	
	@PutMapping("/student")
	public Student updateStudent(@RequestBody Student student) {
		studentService.updateStudent(student);
		return student;
	}
	
	@GetMapping("/student/flush")
	public void removeStudenetDetailsFromCache() {
		studentService.refreshAllStudents();
		System.out.println("Clearing Cache");
	}
}
