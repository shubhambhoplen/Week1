package com.week2.day5.assignment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

/*#3. Make changes in spring-cache to use @Cacheable, @CacheEvict, @CachePut appropriately*/

@SpringBootApplication
@EnableCaching
public class Week2Day5Assignment3Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day5Assignment3Application.class, args);
	}

}
