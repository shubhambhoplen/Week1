package com.week2.day2.assignment2.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.week2.day2.assignment2.Employee;

@RestController
public class ComponentController {
	
	@Autowired
	private ComponentClass compClass;

	@GetMapping("/get/{id}")
	public Employee getEmployee(@PathVariable("id") Integer id) {
		Employee emp = compClass.getEmployee(id);
		if(emp != null)
			return emp;
		return null;
	}
	
	@GetMapping("/add")
	public Employee addEmployee() {
		return compClass.createEmployee();
	}
}
