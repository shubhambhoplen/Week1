package com.week2.day2.assignment2.controller;

import org.springframework.stereotype.Component;

import com.week2.day2.assignment2.Employee;

@Component
public class ComponentClass {

	Employee emp ;
	
	public ComponentClass() {
		emp = new Employee();
	}

	public Employee createEmployee() {

		emp.setEmp_id(111);
		emp.setEmp_name("Employee_name");
		emp.setEmp_sal(16500f);

		return emp;
	}

	public Employee getEmployee(Integer id) {
		if (emp.getEmp_id() == id) {
			return emp;
		}
		return null;
	}

}
