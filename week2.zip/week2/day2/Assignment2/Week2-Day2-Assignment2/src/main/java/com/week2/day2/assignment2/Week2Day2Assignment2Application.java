package com.week2.day2.assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Week2Day2Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day2Assignment2Application.class, args);
	}

}
