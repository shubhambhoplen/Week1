package com.week2.day2.assignment3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*
 * #3. In Employee Spring Boot REST application make necessary changes to use employee id Query parameter, 
 * 				and retrieve details of a specific Employee
 */


@SpringBootApplication
public class Week2Day2Assignment3Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day2Assignment3Application.class, args);
	}

}
