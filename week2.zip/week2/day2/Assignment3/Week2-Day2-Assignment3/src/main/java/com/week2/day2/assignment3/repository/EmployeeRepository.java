package com.week2.day2.assignment3.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.week2.day2.assignment3.Employee;

@Repository
public class EmployeeRepository {

	private List<Employee> empList;

	public EmployeeRepository() {
		empList = new ArrayList<>();
	}

	public Employee addEmployee(Employee emp) {
		empList.add(emp);
		return emp;
	}


	public List<Employee> getAllEmployees() {
		return empList;
	}

	public Employee getEmployeeById(Integer emp_id) {
		for (Employee emp : empList) {
			if (emp.getEmp_id() == emp_id) {
				return emp;
			}
		}
		return null;
	}

	public String deleteEmployee(Integer emp_id) {
		for (Employee emp : empList) {
			if (emp.getEmp_id() == emp_id) {
				empList.remove(emp);
				return "Employee deleted with id " + emp_id;
			}
		}
		return "Employee Id not available";
	}
}
