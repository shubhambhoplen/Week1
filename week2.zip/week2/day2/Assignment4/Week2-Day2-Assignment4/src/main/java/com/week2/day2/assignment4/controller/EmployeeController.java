package com.week2.day2.assignment4.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.week2.day2.assignment4.entity.Employee;
import com.week2.day2.assignment4.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService empService;

	@GetMapping("/all")
	public List<Employee> getEmployees() {
		return empService.getAllEmployees();
	}
	
	@GetMapping("/{emp_id}")
	public Employee getEmployeeById(@PathVariable Integer emp_id) {
		return empService.getEmpById(emp_id);
	}
	
	@GetMapping("/get")
	public Employee getEmployee(@RequestParam("id") Integer emp_id) {
		return empService.getEmpById(emp_id);
	}
	
	@PutMapping("/update")
	public Employee changeEmployee(@RequestParam("id") Integer emp_id, @RequestBody Employee emp) {
		return empService.updateEmployee(emp_id, emp);
	}
	
	@PutMapping("/update/{eid}")
	public ResponseEntity<Employee> modifyEmployee(@PathVariable("eid") Integer emp_id, @RequestBody Employee emp) {
		 Employee empC = empService.updateEmployee(emp_id, emp);
		 HttpHeaders headers = new HttpHeaders();
		 headers.add("Responded", "Employee record updated !!!!");
		 return new ResponseEntity<>(empC , headers, HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public Employee addEmployee(@Valid @RequestBody Employee emp) {
		return empService.createEmployee(emp);
	}
	
	@PostMapping("/addAll")
	public List<Employee> addEmployees(@Valid @RequestBody List<Employee> empList) {
		return empService.createEmployees(empList);
	}
	
	@DeleteMapping("/{emp_id}")
	public String removeEmployeeById(@PathVariable Integer emp_id) {
		return empService.removeEmployee(emp_id);
	}
	
}
