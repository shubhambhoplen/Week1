package com.week2.day2.assignment4.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.week2.day2.assignment4.entity.Employee;
import com.week2.day2.assignment4.repository.EmployeeRepo;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;
	

	@Override
	public Employee createEmployee(Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public List<Employee> createEmployees(List<Employee> empList) {
		return empRepo.saveAll(empList);
	}

	@Override
	public Employee getEmpById(Integer empId) {
		return empRepo.getById(empId);
	}

	@Override
	public String removeEmployee(Integer empId) {
		empRepo.deleteById(empId);
		return "Employee Deleted with Id :" + empId;
	}

	@Override
	public Employee updateEmployee(Integer id, Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return empRepo.findAll();
	}
}
