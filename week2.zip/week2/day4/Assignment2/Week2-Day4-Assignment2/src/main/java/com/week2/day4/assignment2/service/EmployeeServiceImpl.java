package com.week2.day4.assignment2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.week2.day4.assignment2.entity.Employee;
import com.week2.day4.assignment2.repository.EmployeeRepo;


@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo empRepo;
	

	public EmployeeServiceImpl(int i) {
		System.out.println("Print value : "+i);
		}

	@Override
	public Employee createEmployee(Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public List<Employee> createEmployees(List<Employee> empList) {
		return empRepo.saveAll(empList);
	}

	@Override
	public Employee getEmpById(Integer empId) {
		return empRepo.getById(empId);
	}

	@Override
	public List<Employee> getEmployeesBetweenSalaries(Float sal1,Float sal2) {
		List<Employee> empList = empRepo.findAbc1(sal1, sal2);
		empList.forEach(emp -> {
			System.out.println(emp);
		});
		return empList;
	}
	
	@Override
	public List<Employee> getEmployeesByGreaterSalary(Float sal) {
		List<Employee> empList = empRepo.findAbc(sal);
		empList.forEach(emp -> {
			System.out.println(emp);
		});
		return empList;
	}

	@Override
	public String removeEmployee(Integer empId) {
		empRepo.deleteById(empId);
		return "Employee Deleted with Id :" + empId;
	}

	@Override
	public Employee updateEmployee(Integer id, Employee emp) {
		return empRepo.save(emp);
	}

	@Override
	public List<Employee> findByNameContainingAndSalaryGreaterThan(String emp_name, Float salary) {
		return empRepo.getByNameContainingAndGreaterSalary(emp_name, salary);
	}

	@Override
	public List<Employee> getAllEmployees() {
		return empRepo.findAll();
	}
}
