package com.week2.day4.assignment2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*#2. With out the default constructor creator call the ServiceImpl?*/

@SpringBootApplication
public class Week2Day4Assignment2Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day4Assignment2Application.class, args);
	}

}
