package com.week2.day4.assignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
#1. In the Spring boot transaction example provided, 
create nested transactions with required propagation levels in which new inner
 transaction is created and any data updated in inner transaction is 
 not committed to db(when checked exception is thrown).*/

@SpringBootApplication
public class Week2Day4Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day4Assignment1Application.class, args);
	}

}
