package com.week2.day1.assignment2.model;

public class Employee {
	
	private Integer emp_id;
	private String emp_name;
	private Double salary;
	private Address address;
	
	public Employee() {
		System.out.println("Employee() constructor");
	}

	public Employee(Integer emp_id, String emp_name, Double salary, Address address) {
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.salary = salary;
		this.address = address;
	}

	public Integer getEmp_id() {
		return emp_id;
	}

	public void setEmp_id(Integer emp_id) {
		this.emp_id = emp_id;
	}

	public String getEmp_name() {
		return emp_name;
	}

	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Employee [emp_id=" + emp_id + ", emp_name=" + emp_name + ", salary=" + salary + "\n, Address = "+ address +"]";
	}

}
