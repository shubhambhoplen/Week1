package com.week2.day1.assignment2.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import com.week2.day1.assignment2.model.Address;
import com.week2.day1.assignment2.model.Employee;


@Configuration("eConfig")
public class EmployeeConfiguration {
	
	@Bean		
	public Employee getEmployee() {
		Address addr = getAddress();
		Employee emp = new Employee(101, "Employee_name", 10000.00, addr);
		return emp;
	}
	
	@Bean
	@Scope("prototype")
	public Address getAddress() {
		return new Address(123,"City_name","Dist_name",400100);
	}
	
	
	public void display() {
		System.out.println("Employee Object : "+getEmployee());
	}

}
