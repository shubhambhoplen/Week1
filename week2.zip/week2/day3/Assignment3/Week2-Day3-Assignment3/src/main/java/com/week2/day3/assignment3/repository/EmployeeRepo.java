package com.week2.day3.assignment3.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.week2.day3.assignment3.entity.Employee;

@Repository
public interface EmployeeRepo extends JpaRepository<Employee, Integer> {

	@Query(value="SELECT * FROM Employee e WHERE e.emp_name like %:name% AND e.emp_sal > :salry ", nativeQuery=true)
	List<Employee> getByNameContainingAndGreaterSalary(@Param("name") String emp_name, @Param("salry") Float salary);
	
	@Query("SELECT e FROM Employee e WHERE e.emp_sal > :salry") //Named parameter
    List<Employee> findAbc(@Param("salry") Float salary);
	
	@Query(value="SELECT * FROM Employee e WHERE e.emp_sal > :salry AND e.emp_sal < :salry2 ", nativeQuery=true)//Named parameter
    List<Employee> findAbc1(@Param("salry") Float salary, @Param("salry2") Float salary2);

}
