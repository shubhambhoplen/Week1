package com.week2.day3.assignment5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/*#5. Verify working of @Transaction with rollbackFor attribute,
 *  when checked exceptions are thrown*/

@SpringBootApplication
public class Week2Day3Assignment5Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day3Assignment5Application.class, args);
	}

}
