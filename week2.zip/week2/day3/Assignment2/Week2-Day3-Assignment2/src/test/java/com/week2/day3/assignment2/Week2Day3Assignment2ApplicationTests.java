package com.week2.day3.assignment2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Week2Day3Assignment2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
