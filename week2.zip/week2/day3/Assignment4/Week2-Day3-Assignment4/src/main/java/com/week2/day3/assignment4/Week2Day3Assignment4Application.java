package com.week2.day3.assignment4;

/*#4. In Junit mockito example provided, 
 * add testcase to test mul() method defined in ArithBusinessLogic.java*/


public class Week2Day3Assignment4Application {

	public static void main(String[] args) {
	}

}
