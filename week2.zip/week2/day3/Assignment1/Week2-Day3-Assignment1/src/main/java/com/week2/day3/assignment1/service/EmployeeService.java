package com.week2.day3.assignment1.service;

import java.util.List;

import com.week2.day3.assignment1.entity.Employee;

public interface EmployeeService {
	
	public Employee createEmployee(Employee emp);

	public Employee updateEmployee(Integer id, Employee emp);
	
	public List<Employee> createEmployees(List<Employee> empList);

	public Employee getEmpById(Integer empId);

	public List<Employee> getAllEmployees();

	public String removeEmployee(Integer empId);
	
	public List<Employee> findByNameContainingAndSalaryGreaterThan(String emp_name, Float salary);

	public List<Employee> getEmployeesByGreaterSalary(Float sal);
	
}
