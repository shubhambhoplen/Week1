package com.week2.day3.assignment1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/*
#1. In Employee SPring boot JPA example, 
use derived query method, to retrieve Employee name contains and salary greater than 1000?*/

@SpringBootApplication
public class Week2Day3Assignment1Application {

	public static void main(String[] args) {
		SpringApplication.run(Week2Day3Assignment1Application.class, args);
	}

}
